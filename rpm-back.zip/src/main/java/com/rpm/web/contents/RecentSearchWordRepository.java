package com.rpm.web.contents;

import org.springframework.data.repository.CrudRepository;

public interface RecentSearchWordRepository extends CrudRepository<RecentSearchWord, Long> {
}
